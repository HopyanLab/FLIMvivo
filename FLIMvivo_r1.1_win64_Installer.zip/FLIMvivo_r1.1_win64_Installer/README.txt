FLIMvivo Release 1.1

To install FLIMvivo, run FLIMvivo_r1.1_win64_Installer.exe.

This will download and run the setup file for the FLIMvivo GUI.  